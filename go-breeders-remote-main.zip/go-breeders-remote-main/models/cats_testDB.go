package models

func (m *testRepository) GetCatBreedByID(id int) (*CatBreed, error) {
	return nil, nil
}

func (m *testRepository) RandomCatBreed() (*CatBreed, error) {
	return nil, nil
}

func (m *testRepository) AllCatBreeds() ([]*CatBreed, error) {
	return nil, nil
}

// RandomCatOfSize returns a random dog within a specified weight range.
func (m *testRepository) RandomCatOfSize(minWeight, maxWeight int) (*CatBreed, error) {
	return nil, nil
}

func (m *testRepository) GetCatBreedByName(id string) (*CatBreed, error) {
	return nil, nil
}
