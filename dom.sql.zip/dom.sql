CREATE TABLE `dog_of_month` (
                                `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                `image` varchar(512) NOT NULL,
                                `video` varchar(512) NOT NULL,
                                PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;